package com.wuxia.music

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "folders", indices = [Index(value = ["treeUri"], unique = true)])
data class FolderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val treeUri: String,
    val label: String,
    val missing: Boolean = false
)

@Entity(tableName = "songs", indices = [Index("folderId")])
data class SongEntity(
    @PrimaryKey val uri: String,
    val folderId: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val fileName: String,
    val lastModified: Long
)

@Entity(tableName = "favorites")
data class FavoriteEntity(@PrimaryKey val uri: String)

@Entity(tableName = "recents")
data class RecentEntity(@PrimaryKey val uri: String, val playedAt: Long)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val folderId: Long? = null
)

@Entity(tableName = "playlist_items", primaryKeys = ["playlistId", "uri"])
data class PlaylistItem(val playlistId: Long, val uri: String)

@Dao
abstract class MusicDao {
    @Query("SELECT * FROM folders ORDER BY id") abstract fun folders(): Flow<List<FolderEntity>>
    @Query("SELECT * FROM folders ORDER BY id") abstract suspend fun folderList(): List<FolderEntity>
    @Insert(onConflict = OnConflictStrategy.IGNORE) abstract suspend fun insertFolder(f: FolderEntity): Long
    @Query("UPDATE folders SET label = :label WHERE id = :id") abstract suspend fun renameFolder(id: Long, label: String)
    @Query("UPDATE folders SET missing = :m WHERE id = :id") abstract suspend fun setMissing(id: Long, m: Boolean)
    @Query("DELETE FROM folders WHERE id = :id") abstract suspend fun deleteFolderRow(id: Long)
    @Query("DELETE FROM songs WHERE folderId = :id") abstract suspend fun deleteSongsOf(id: Long)

    @Query("SELECT * FROM songs") abstract fun songs(): Flow<List<SongEntity>>
    @Query("SELECT * FROM songs") abstract suspend fun songList(): List<SongEntity>
    @Query("SELECT * FROM songs WHERE folderId = :id") abstract suspend fun songsOf(id: Long): List<SongEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) abstract suspend fun insertSongs(list: List<SongEntity>)

    @Transaction
    open suspend fun replaceSongs(id: Long, list: List<SongEntity>) {
        deleteSongsOf(id); insertSongs(list)
    }

    @Transaction
    open suspend fun removeFolder(id: Long) {
        deleteSongsOf(id); deleteFolderRow(id)
    }

    @Query("SELECT uri FROM favorites") abstract fun favorites(): Flow<List<String>>
    @Insert(onConflict = OnConflictStrategy.IGNORE) abstract suspend fun addFavorite(f: FavoriteEntity)
    @Query("DELETE FROM favorites WHERE uri = :uri") abstract suspend fun removeFavorite(uri: String)

    @Query("SELECT uri FROM recents ORDER BY playedAt DESC LIMIT 50") abstract fun recents(): Flow<List<String>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) abstract suspend fun addRecent(r: RecentEntity)

    @Query("SELECT * FROM playlists ORDER BY id") abstract fun playlists(): Flow<List<PlaylistEntity>>
    @Insert abstract suspend fun insertPlaylist(p: PlaylistEntity): Long
    @Query("UPDATE playlists SET name = :name WHERE id = :id") abstract suspend fun renamePlaylist(id: Long, name: String)
    @Query("DELETE FROM playlists WHERE id = :id") abstract suspend fun deletePlaylistRow(id: Long)
    @Query("DELETE FROM playlist_items WHERE playlistId = :id") abstract suspend fun deleteItemsOf(id: Long)

    @Transaction
    open suspend fun deletePlaylist(id: Long) {
        deleteItemsOf(id); deletePlaylistRow(id)
    }

    @Query("SELECT * FROM playlist_items") abstract fun playlistItems(): Flow<List<PlaylistItem>>
    @Insert(onConflict = OnConflictStrategy.IGNORE) abstract suspend fun addToPlaylist(i: PlaylistItem)
    @Query("DELETE FROM playlist_items WHERE playlistId = :pid AND uri = :uri")
    abstract suspend fun removeFromPlaylist(pid: Long, uri: String)
}

@Database(
    entities = [FolderEntity::class, SongEntity::class, FavoriteEntity::class,
        RecentEntity::class, PlaylistEntity::class, PlaylistItem::class],
    version = 1, exportSchema = false
)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): MusicDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "music.db")
                .build().also { inst = it }
        }
    }
}

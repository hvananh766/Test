package com.wuxia.music

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MusicApp(vm: MusicViewModel) {
    CompositionLocalProvider(LocalLang provides vm.lang) {
        WuxiaTheme(vm.dark) {
            val ctx = LocalContext.current
            val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
            val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
                if (uri != null) vm.addFolder(uri)
            }
            LaunchedEffect(Unit) {
                if (Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            BackHandler(enabled = vm.showPlayer || vm.stack.size > 1) {
                if (vm.showPlayer) vm.showPlayer = false else vm.back()
            }
            CompositionLocalProvider(LocalPickFolder provides { picker.launch(null) }) {
                Surface(color = Color.Transparent, contentColor = MaterialTheme.colorScheme.onBackground) {
                    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
                        Column(Modifier.fillMaxSize().statusBarsPadding()) {
                            Box(Modifier.weight(1f)) {
                                AnimatedContent(
                                    vm.current,
                                    transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) },
                                    label = "screen"
                                ) { s -> ScreenHost(vm, s) }
                            }
                            if (vm.currentSong != null) MiniPlayer(vm)
                            BottomBar(vm)
                        }
                        AnimatedVisibility(
                            vm.showPlayer,
                            enter = slideInVertically { it } + fadeIn(),
                            exit = slideOutVertically { it } + fadeOut()
                        ) { PlayerScreen(vm) }
                        vm.pickSong?.let { AddToPlaylistDialog(vm, it) }
                    }
                }
            }
        }
    }
}

@Composable
fun ScreenHost(vm: MusicViewModel, s: Screen) {
    when (s) {
        Screen.Home -> HomeScreen(vm)
        Screen.Folders -> FoldersScreen(vm)
        Screen.Playlists -> PlaylistsScreen(vm)
        Screen.Albums -> GroupScreen(vm, true)
        Screen.Artists -> GroupScreen(vm, false)
        Screen.Settings -> SettingsScreen(vm)
        Screen.Equalizer -> EqualizerScreen(vm)
        is Screen.Songs -> SongsScreen(vm, s)
    }
}

@Composable
fun BottomBar(vm: MusicViewModel) {
    val cur = vm.current
    val allSongs = Screen.Songs("ALL", "", tr("Tất cả bài hát", "All songs"))
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)) {
        @Composable
        fun item(sel: Boolean, icon: ImageVector, label: String, target: Screen) =
            NavigationBarItem(
                selected = sel, onClick = { vm.goRoot(target) },
                icon = { Icon(icon, null) }, label = { Text(label, maxLines = 1, style = MaterialTheme.typography.labelSmall) }
            )
        item(cur == Screen.Home, Icons.Filled.Home, tr("Trang chủ", "Home"), Screen.Home)
        item(cur is Screen.Songs && cur.kind == "ALL", Icons.Filled.MusicNote, tr("Bài hát", "Songs"), allSongs)
        item(cur == Screen.Folders, Icons.Filled.Folder, tr("Thư mục", "Folders"), Screen.Folders)
        item(cur == Screen.Playlists, Icons.Filled.LibraryMusic, "Playlist", Screen.Playlists)
        item(cur == Screen.Settings, Icons.Filled.Settings, tr("Cài đặt", "Settings"), Screen.Settings)
    }
}

// ---------------- HOME ----------------
@Composable
fun Tile(icon: ImageVector, label: String, count: Int, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(panelColor())
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick).padding(12.dp)
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.secondary)
        Spacer(Modifier.height(6.dp))
        Text(label, fontWeight = FontWeight.Medium, maxLines = 1)
        Text("$count", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun HomeScreen(vm: MusicViewModel) {
    val songs by vm.songs.collectAsState()
    val folders by vm.folders.collectAsState()
    val recents by vm.recents.collectAsState()
    val favs by vm.favorites.collectAsState()
    val pls by vm.playlists.collectAsState()
    val byUri = remember(songs) { songs.associateBy { it.uri } }
    val recentSongs = remember(recents, songs) { recents.mapNotNull { byUri[it] } }
    val counts = remember(songs) { songs.groupingBy { it.folderId }.eachCount() }
    val cs = MaterialTheme.colorScheme
    val pick = LocalPickFolder.current
    val allTitle = tr("Tất cả bài hát", "All songs")
    val favTitle = tr("Yêu thích", "Favorites")
    val recentTitle = tr("Phát gần đây", "Recently played")

    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
        item { TopBar("Music", null) }
        item {
            Column(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Tile(Icons.Filled.MusicNote, tr("Tất cả", "All"), songs.size, Modifier.weight(1f)) {
                        vm.go(Screen.Songs("ALL", "", allTitle))
                    }
                    Tile(Icons.Filled.Album, "Album", songs.map { it.album }.distinct().size, Modifier.weight(1f)) { vm.go(Screen.Albums) }
                    Tile(Icons.Filled.Person, tr("Nghệ sĩ", "Artists"), songs.map { it.artist }.distinct().size, Modifier.weight(1f)) { vm.go(Screen.Artists) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Tile(Icons.Filled.LibraryMusic, "Playlist", pls.size, Modifier.weight(1f)) { vm.go(Screen.Playlists) }
                    Tile(Icons.Filled.Favorite, tr("Yêu thích", "Favorites"), favs.size, Modifier.weight(1f)) {
                        vm.go(Screen.Songs("FAV", "", favTitle))
                    }
                    Tile(Icons.Filled.History, tr("Gần đây", "Recent"), recentSongs.size, Modifier.weight(1f)) {
                        vm.go(Screen.Songs("RECENT", "", recentTitle))
                    }
                }
            }
        }
        if (folders.isEmpty()) item {
            Column(
                Modifier.padding(16.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(panelColor()).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(tr("Chưa có nhạc. Hãy chọn thư mục chứa nhạc của bạn — chỉ những thư mục bạn chọn mới được phát.",
                    "No music yet. Pick the folders that hold your music — only those folders are used."),
                    textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Button(onClick = pick) { Text(tr("Chọn thư mục nhạc", "Choose music folder")) }
            }
        }
        if (recentSongs.isNotEmpty()) {
            item { SectionTitle(tr("Nghe gần đây", "Recently played")) }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    itemsIndexed(recentSongs.take(20), key = { _, s -> s.uri }) { i, s ->
                        Column(Modifier.width(112.dp).clickable { vm.play(recentSongs, i) }) {
                            Artwork(s.uri, Modifier.size(112.dp), 12.dp)
                            Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                            Text(artistOf(s), maxLines = 1, overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        if (folders.isNotEmpty()) {
            item { SectionTitle(tr("Thư mục đã chọn", "Selected folders")) }
            items(folders, key = { it.id }) { f ->
                Row(
                    Modifier.fillMaxWidth().clickable { vm.go(Screen.Songs("FOLDER", f.id.toString(), f.label)) }
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Folder, null, tint = Accent)
                    Spacer(Modifier.width(12.dp))
                    Text(f.label, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(tr("${counts[f.id] ?: 0} bài", "${counts[f.id] ?: 0} songs"),
                        style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            }
        }
    }
}

// ---------------- SONG LIST (all / folder / album / artist / playlist / fav / recent) ----------------
@Composable
fun SongsScreen(vm: MusicViewModel, scr: Screen.Songs) {
    val all by vm.songs.collectAsState()
    val favs by vm.favorites.collectAsState()
    val recents by vm.recents.collectAsState()
    val items by vm.playlistItems.collectAsState()
    val byUri = remember(all) { all.associateBy { it.uri } }
    val favSet = remember(favs) { favs.toSet() }
    val base: List<SongEntity> = when (scr.kind) {
        "ALL" -> all
        "FAV" -> favs.mapNotNull { byUri[it] }
        "RECENT" -> recents.mapNotNull { byUri[it] }
        "FOLDER" -> all.filter { it.folderId.toString() == scr.key }
        "ALBUM" -> all.filter { it.album == scr.key }
        "ARTIST" -> all.filter { it.artist == scr.key }
        "PLAYLIST" -> items.filter { it.playlistId.toString() == scr.key }.mapNotNull { byUri[it.uri] }
        else -> emptyList()
    }
    var query by remember { mutableStateOf("") }
    var showSort by remember { mutableStateOf(false) }
    val sort = vm.sort
    val keepOrder = scr.kind in listOf("FAV", "RECENT", "PLAYLIST")
    val shown = remember(base, query, sort) {
        val f = if (query.isBlank()) base else base.filter {
            it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true)
        }
        if (keepOrder) f else sortSongs(f, sort)
    }
    Column(Modifier.fillMaxSize()) {
        TopBar(scr.title, if (vm.stack.size > 1) ({ vm.back() }) else null) {
            if (scr.kind == "FOLDER") IconButton(onClick = { vm.refreshFolder(scr.key.toLong()) }) {
                Icon(Icons.Filled.Refresh, tr("Làm mới", "Refresh"), tint = MaterialTheme.colorScheme.secondary)
            }
        }
        if (vm.scanning) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (showSort) SortDialog(vm.sort, { vm.applySort(it); showSort = false }, { showSort = false })
        OutlinedTextField(
            query, { query = it }, singleLine = true,
            placeholder = { Text(tr("Tìm bài hát…", "Search songs…")) },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
        )
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(
                Modifier.weight(1f).clickable(enabled = shown.isNotEmpty()) { vm.play(shown, 0, false) }.padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(32.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.PlayArrow, null, Modifier.size(20.dp)) }
                Spacer(Modifier.width(10.dp))
                Text(tr("Phát tất cả (${shown.size} bài)", "Play all (${shown.size} songs)"), style = MaterialTheme.typography.titleMedium)
            }
            IconButton(onClick = { vm.shuffleAll(shown) }, enabled = shown.isNotEmpty()) { Icon(Icons.Filled.Shuffle, null) }
            if (!keepOrder) IconButton(onClick = { showSort = true }) { Icon(Icons.Filled.Sort, null) }
        }
        if (shown.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(tr("Không có bài hát nào.", "No songs here."), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(shown, key = { _, s -> s.uri }) { i, s ->
                SongRow(vm, s, s.uri == vm.currentUri, favSet.contains(s.uri), { vm.play(shown, i) },
                    if (scr.kind == "PLAYLIST") ({ vm.removeFromPlaylist(scr.key.toLong(), s.uri) }) else null)
            }
        }
    }
}

// ---------------- ALBUMS / ARTISTS ----------------
@Composable
fun GroupScreen(vm: MusicViewModel, albums: Boolean) {
    val songs by vm.songs.collectAsState()
    val groups = remember(songs, albums) {
        songs.groupBy { if (albums) it.album else it.artist }.toList().sortedBy { it.first.lowercase() }
    }
    val unknown = tr("Không rõ", "Unknown")
    Column(Modifier.fillMaxSize()) {
        TopBar(if (albums) "Album" else tr("Nghệ sĩ", "Artists"), { vm.back() })
        LazyColumn(Modifier.fillMaxSize()) {
            items(groups, key = { it.first }) { (name, list) ->
                val label = name.ifBlank { unknown }
                Row(
                    Modifier.fillMaxWidth().clickable {
                        vm.go(Screen.Songs(if (albums) "ALBUM" else "ARTIST", name, label))
                    }.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Artwork(list.first().uri, Modifier.size(52.dp), if (albums) 8.dp else 26.dp)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(label, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(tr("${list.size} bài", "${list.size} songs"), style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

// ---------------- FOLDERS ----------------
@Composable
fun FoldersScreen(vm: MusicViewModel) {
    val folders by vm.folders.collectAsState()
    val songs by vm.songs.collectAsState()
    val counts = remember(songs) { songs.groupingBy { it.folderId }.eachCount() }
    val pick = LocalPickFolder.current
    var renaming by remember { mutableStateOf<FolderEntity?>(null) }
    var removing by remember { mutableStateOf<FolderEntity?>(null) }
    Column(Modifier.fillMaxSize()) {
        TopBar(tr("Thư mục nhạc", "Music folders"), null) {
            IconButton(onClick = { vm.refreshAll() }) { Icon(Icons.Filled.Refresh, null, tint = MaterialTheme.colorScheme.secondary) }
            IconButton(onClick = pick) { Icon(Icons.Filled.CreateNewFolder, null, tint = MaterialTheme.colorScheme.secondary) }
        }
        if (vm.scanning) LinearProgressIndicator(Modifier.fillMaxWidth())
        Text(
            tr("Chỉ phát nhạc từ các thư mục bạn chọn. Gỡ thư mục chỉ xoá khỏi ứng dụng, tệp gốc giữ nguyên.",
                "Only folders you pick are played. Removing a folder only removes it from the app; files stay untouched."),
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        if (folders.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Button(onClick = pick) { Text(tr("Thêm thư mục", "Add folder")) }
            }
        } else LazyColumn(Modifier.fillMaxSize()) {
            items(folders, key = { it.id }) { f ->
                var menu by remember { mutableStateOf(false) }
                Row(
                    Modifier.fillMaxWidth().clickable { vm.go(Screen.Songs("FOLDER", f.id.toString(), f.label)) }
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(if (f.missing) Icons.Filled.FolderOff else Icons.Filled.Folder, null,
                        tint = if (f.missing) MaterialTheme.colorScheme.error else Accent)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(f.label, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            if (f.missing) tr("Không truy cập được — thử làm mới", "Unavailable — try refreshing")
                            else tr("${counts[f.id] ?: 0} bài hát", "${counts[f.id] ?: 0} songs"),
                            style = MaterialTheme.typography.bodySmall,
                            color = if (f.missing) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, null) }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem({ Text(tr("Phát tất cả", "Play all")) }, {
                                menu = false
                                vm.play(sortSongs(songs.filter { it.folderId == f.id }, vm.sort), 0, false)
                            })
                            DropdownMenuItem({ Text(tr("Ngẫu nhiên", "Shuffle")) }, {
                                menu = false; vm.shuffleAll(songs.filter { it.folderId == f.id })
                            })
                            DropdownMenuItem({ Text(tr("Làm mới", "Refresh")) }, { menu = false; vm.refreshFolder(f.id) })
                            DropdownMenuItem({ Text(tr("Đổi tên nhãn", "Rename label")) }, { menu = false; renaming = f })
                            DropdownMenuItem({ Text(tr("Gỡ thư mục", "Remove folder")) }, { menu = false; removing = f })
                        }
                    }
                }
            }
        }
    }
    renaming?.let { f ->
        TextDialog(tr("Đổi tên nhãn", "Rename label"), f.label, { renaming = null }) { vm.renameFolder(f.id, it); renaming = null }
    }
    removing?.let { f ->
        AlertDialog(
            onDismissRequest = { removing = null },
            title = { Text(tr("Gỡ thư mục?", "Remove folder?")) },
            text = { Text(tr("Bài hát sẽ biến mất khỏi thư viện nhưng tệp trên điện thoại không bị xoá.",
                "Songs disappear from the library, but files on your phone are not deleted.")) },
            confirmButton = { TextButton(onClick = { vm.removeFolder(f); removing = null }) { Text(tr("Gỡ", "Remove")) } },
            dismissButton = { TextButton(onClick = { removing = null }) { Text(tr("Huỷ", "Cancel")) } }
        )
    }
}

// ---------------- PLAYLISTS ----------------
@Composable
fun PlaylistsScreen(vm: MusicViewModel) {
    val pls by vm.playlists.collectAsState()
    val items by vm.playlistItems.collectAsState()
    val folders by vm.folders.collectAsState()
    val songs by vm.songs.collectAsState()
    val present = remember(songs) { songs.map { it.uri }.toHashSet() }
    var creating by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<PlaylistEntity?>(null) }
    Column(Modifier.fillMaxSize()) {
        TopBar("Playlist", null) {
            IconButton(onClick = { creating = true }) { Icon(Icons.Filled.Add, null, tint = MaterialTheme.colorScheme.secondary) }
        }
        if (pls.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(tr("Chưa có playlist. Nhấn + để tạo.", "No playlists yet. Tap + to create one."),
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else LazyColumn(Modifier.fillMaxSize()) {
            items(pls, key = { it.id }) { p ->
                var menu by remember { mutableStateOf(false) }
                val n = items.count { it.playlistId == p.id && it.uri in present }
                val fl = folders.firstOrNull { it.id == p.folderId }?.label
                Row(
                    Modifier.fillMaxWidth().clickable { vm.go(Screen.Songs("PLAYLIST", p.id.toString(), p.name)) }
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.LibraryMusic, null, tint = Accent)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(tr("$n bài", "$n songs") + (fl?.let { " · $it" } ?: ""),
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, null) }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem({ Text(tr("Đổi tên", "Rename")) }, { menu = false; renaming = p })
                            DropdownMenuItem({ Text(tr("Xoá playlist", "Delete playlist")) }, { menu = false; vm.deletePlaylist(p.id) })
                        }
                    }
                }
            }
        }
    }
    if (creating) NewPlaylistDialog(folders, { creating = false }) { n, f -> vm.createPlaylist(n, f); creating = false }
    renaming?.let { p ->
        TextDialog(tr("Đổi tên", "Rename"), p.name, { renaming = null }) { vm.renamePlaylist(p.id, it); renaming = null }
    }
}

// ---------------- SETTINGS ----------------
@Composable
fun SettingsScreen(vm: MusicViewModel) {
    val ctx = LocalContext.current
    val version = remember { try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (e: Exception) { "1.0" } }
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar(tr("Cài đặt", "Settings"), null)
        SectionTitle(tr("Giao diện", "Theme"))
        Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(tr("Chế độ tối", "Dark mode"), Modifier.weight(1f))
            Switch(vm.dark, { vm.applyDark(it) })
        }
        SectionTitle(tr("Ngôn ngữ", "Language"))
        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(vm.lang == "vi", { vm.applyLang("vi") }, { Text("Tiếng Việt") })
            FilterChip(vm.lang == "en", { vm.applyLang("en") }, { Text("English") })
        }
        SectionTitle(tr("Âm thanh", "Audio"))
        Text(tr("Tốc độ phát", "Playback speed"), Modifier.padding(horizontal = 16.dp), color = cs.onSurfaceVariant)
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(listOf(0.75f, 1f, 1.25f, 1.5f, 2f)) { s ->
                FilterChip(vm.speed == s, { vm.applySpeed(s) }, { Text("${s}x") })
            }
        }
        TextButton(onClick = { vm.go(Screen.Equalizer) }, Modifier.padding(horizontal = 8.dp)) {
            Icon(Icons.Filled.Equalizer, null); Spacer(Modifier.width(8.dp)); Text(tr("Bộ chỉnh âm", "Equalizer"))
        }
        SectionTitle(tr("Thư mục", "Folders"))
        TextButton(onClick = { vm.goRoot(Screen.Folders) }, Modifier.padding(horizontal = 8.dp)) {
            Icon(Icons.Filled.Folder, null); Spacer(Modifier.width(8.dp)); Text(tr("Quản lý thư mục nhạc", "Manage music folders"))
        }
        SectionTitle(tr("Hẹn giờ tắt nhạc", "Sleep timer"))
        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(0, 15, 30, 45, 60).forEach { m ->
                FilterChip(false, { vm.setSleep(m) }, { Text(if (m == 0) tr("Tắt", "Off") else "$m'") })
            }
        }
        if (vm.sleepEnd > System.currentTimeMillis()) {
            val at = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(vm.sleepEnd))
            Text(tr("Sẽ dừng nhạc lúc $at", "Music will stop at $at"), Modifier.padding(16.dp, 6.dp), color = cs.primary)
        }
        SectionTitle(tr("Giới thiệu", "About"))
        Text("MUSIC — ${tr("trình phát nhạc ngoại tuyến phong cách võ hiệp", "offline wuxia-style music player")}",
            Modifier.padding(horizontal = 16.dp))
        Text("${tr("Phiên bản", "Version")} $version", Modifier.padding(16.dp, 4.dp, 16.dp, 24.dp), color = cs.onSurfaceVariant)
    }
}

// ---------------- EQUALIZER ----------------
@Composable
fun EqualizerScreen(vm: MusicViewModel) {
    val ctx = LocalContext.current
    val supported = vm.prefs.getBoolean("eq_supported", true)
    val names = listOf(tr("Bình thường", "Normal"), "Rock", "Pop", tr("Cổ điển", "Classical"), "Jazz")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar(tr("Bộ chỉnh âm", "Equalizer"), { vm.back() })
        if (!supported) Text(
            tr("Thiết bị này không hỗ trợ bộ chỉnh âm.", "This device does not support the equalizer."),
            Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error
        )
        SectionTitle(tr("Cài đặt sẵn", "Presets"))
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            itemsIndexed(names) { i, n ->
                FilterChip(vm.eqPreset == i, { vm.setEq(preset = i) }, { Text(n) }, enabled = supported)
            }
        }
        SectionTitle("Bass")
        Slider(vm.eqBass, { vm.setEq(bass = it) }, valueRange = -1f..1f, enabled = supported,
            modifier = Modifier.padding(horizontal = 16.dp))
        SectionTitle("Treble")
        Slider(vm.eqTreble, { vm.setEq(treble = it) }, valueRange = -1f..1f, enabled = supported,
            modifier = Modifier.padding(horizontal = 16.dp))
    }
}

// ---------------- MINI PLAYER ----------------
@Composable
fun MiniPlayer(vm: MusicViewModel) {
    val s = vm.currentSong ?: return
    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface.copy(alpha = 0.92f))
        .clickable { vm.showPlayer = true }) {
        LinearProgressIndicator(
            progress = { (vm.position.toFloat() / vm.duration.coerceAtLeast(1L)).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(2.dp)
        )
        Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Artwork(s.uri, Modifier.size(42.dp), 8.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Text(artistOf(s), maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = { vm.togglePlay() }) {
                Icon(if (vm.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = MaterialTheme.colorScheme.primary)
            }
            IconButton(onClick = { vm.next() }) { Icon(Icons.Filled.SkipNext, null) }
        }
    }
}

// ---------------- SORT DIALOG ----------------
@Composable
fun SortDialog(current: Int, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    val opts = listOf(
        tr("Theo tên nghệ sĩ (A–Z)", "By artist name (A–Z)"),
        tr("Theo tên bài hát (A–Z)", "By song name (A–Z)"),
        tr("Theo tên tệp (A–Z)", "By filename (A–Z)"),
        tr("Theo thời gian thêm (mới nhất trước)", "By time added (newest on top)"),
        tr("Theo thời gian thêm (cũ nhất trước)", "By time added (oldest on top)"),
        tr("Theo chất lượng âm thanh (cao nhất trước)", "By sound quality (highest on top)")
    )
    val cs = MaterialTheme.colorScheme
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Sắp xếp theo", "Sort by"), Modifier.fillMaxWidth(), textAlign = TextAlign.Center) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                opts.forEachIndexed { i, label ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(i) }.padding(vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(label, Modifier.weight(1f), color = if (i == current) cs.primary else cs.onSurface)
                        if (i == current) Icon(Icons.Filled.Check, null, tint = cs.primary)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss, Modifier.fillMaxWidth()) { Text(tr("Huỷ", "Cancel"), color = cs.onSurface) }
        }
    )
}

// ---------------- FULL PLAYER ----------------
@Composable
fun PlayerScreen(vm: MusicViewModel) {
    val s = vm.currentSong ?: return
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val favs by vm.favorites.collectAsState()
    val isFav = favs.contains(s.uri)
    val scale by animateFloatAsState(if (vm.isPlaying) 1f else 0.94f, tween(500), label = "scale")
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat() }
    var vol by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }
    var showVol by remember { mutableStateOf(false) }
    var drag by remember { mutableStateOf<Float?>(null) }
    var sleepMenu by remember { mutableStateOf(false) }
    val dur = vm.duration.coerceAtLeast(1L)
    val frac = drag ?: (vm.position.toFloat() / dur).coerceIn(0f, 1f)

    Column(
        Modifier.fillMaxSize().background(cs.background)
            .statusBarsPadding().navigationBarsPadding()
            .padding(horizontal = 24.dp).verticalScroll(rememberScrollState())
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.showPlayer = false }) { Icon(Icons.Filled.KeyboardArrowDown, null) }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { vm.queueOpen = true }) { Icon(Icons.Filled.QueueMusic, null) }
        }
        Spacer(Modifier.height(8.dp))
        Artwork(
            s.uri,
            Modifier.fillMaxWidth().aspectRatio(1f).graphicsLayer { scaleX = scale; scaleY = scale },
            24.dp
        )
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(s.title, style = MaterialTheme.typography.headlineMedium.copy(fontSize = 24.sp),
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                Text(artistOf(s), color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.width(12.dp))
            Box(
                Modifier.size(52.dp).clip(CircleShape).background(cs.surfaceVariant).clickable { vm.toggleFav(s.uri) },
                contentAlignment = Alignment.Center
            ) {
                Icon(if (isFav) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, null,
                    tint = if (isFav) cs.primary else cs.onSurface)
            }
        }
        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.showPlayer = false; vm.go(Screen.Equalizer) }) {
                Icon(Icons.Filled.Equalizer, null, tint = cs.onSurfaceVariant)
            }
            Box {
                IconButton(onClick = { sleepMenu = true }) {
                    Icon(Icons.Filled.Timer, null, tint = if (vm.sleepEnd > System.currentTimeMillis()) cs.primary else cs.onSurfaceVariant)
                }
                DropdownMenu(sleepMenu, { sleepMenu = false }) {
                    listOf(0, 15, 30, 45, 60).forEach { m ->
                        DropdownMenuItem({ Text(if (m == 0) tr("Tắt hẹn giờ", "Timer off") else tr("$m phút", "$m min")) },
                            { sleepMenu = false; vm.setSleep(m) })
                    }
                }
            }
            val speeds = listOf(0.75f, 1f, 1.25f, 1.5f, 2f)
            TextButton(onClick = {
                val i = speeds.indexOf(vm.speed).let { if (it < 0) 1 else it }
                vm.applySpeed(speeds[(i + 1) % speeds.size])
            }) { Text("${vm.speed}x", color = cs.onSurfaceVariant) }
            IconButton(onClick = { showVol = !showVol }) {
                Icon(Icons.Filled.VolumeUp, null, tint = if (showVol) cs.primary else cs.onSurfaceVariant)
            }
        }
        if (showVol) Slider(
            vol, { vol = it; am.setStreamVolume(AudioManager.STREAM_MUSIC, it.toInt(), 0) },
            valueRange = 0f..maxVol
        )
        Slider(
            frac, { drag = it },
            onValueChangeFinished = { drag?.let { vm.seek((it * dur).toLong()) }; drag = null },
            colors = SliderDefaults.colors(
                thumbColor = cs.onBackground, activeTrackColor = cs.onBackground, inactiveTrackColor = cs.surfaceVariant
            )
        )
        Row(Modifier.fillMaxWidth()) {
            Text(fmt((frac * dur).toLong()), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
            Spacer(Modifier.weight(1f))
            Text(fmt(vm.duration), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.toggleShuffle() }) {
                Icon(Icons.Filled.Shuffle, null, tint = if (vm.shuffle) cs.primary else cs.onSurface)
            }
            IconButton(onClick = { vm.prev() }, Modifier.size(56.dp)) { Icon(Icons.Filled.SkipPrevious, null, Modifier.size(36.dp)) }
            Box(
                Modifier.size(84.dp).clip(CircleShape).background(cs.surface).clickable { vm.togglePlay() },
                contentAlignment = Alignment.Center
            ) {
                Icon(if (vm.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, Modifier.size(44.dp))
            }
            IconButton(onClick = { vm.next() }, Modifier.size(56.dp)) { Icon(Icons.Filled.SkipNext, null, Modifier.size(36.dp)) }
            IconButton(onClick = { vm.cycleRepeat() }) {
                Icon(if (vm.repeat == 1) Icons.Filled.RepeatOne else Icons.Filled.Repeat, null,
                    tint = if (vm.repeat != 0) cs.primary else cs.onSurface)
            }
        }
        Spacer(Modifier.height(16.dp))
    }
    if (vm.queueOpen) {
        val tick = vm.queueTick
        val q = remember(tick) { vm.queue() }
        AlertDialog(
            onDismissRequest = { vm.queueOpen = false },
            title = { Text(tr("Hàng chờ", "Queue")) },
            text = {
                LazyColumn {
                    itemsIndexed(q) { i, m ->
                        Text(
                            m.mediaMetadata.title?.toString() ?: "?",
                            Modifier.fillMaxWidth().clickable { vm.jumpTo(i) }.padding(vertical = 10.dp),
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = if (m.mediaId == vm.currentUri) cs.primary else cs.onSurface
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { vm.queueOpen = false }) { Text(tr("Đóng", "Close")) } }
        )
    }
}

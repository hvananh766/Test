package com.wuxia.music

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document

/** Scans ONLY the SAF tree the user picked. Read-only: never modifies files. */
object Scanner {
    private val EXTS = setOf("mp3", "flac", "wav", "m4a", "aac", "ogg")

    /** Returns null when the folder is unreachable (deleted / unmounted / permission lost). */
    fun scan(ctx: Context, folderId: Long, tree: Uri, existing: Map<String, SongEntity>): List<SongEntity>? {
        val out = ArrayList<SongEntity>()
        val rootId = try { DocumentsContract.getTreeDocumentId(tree) } catch (e: Exception) { return null }
        return if (walk(ctx, folderId, tree, rootId, existing, out, 0)) out else null
    }

    private fun walk(
        ctx: Context, folderId: Long, tree: Uri, docId: String,
        existing: Map<String, SongEntity>, out: MutableList<SongEntity>, depth: Int
    ): Boolean {
        if (depth > 12) return true
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(
            Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME,
            Document.COLUMN_MIME_TYPE, Document.COLUMN_LAST_MODIFIED
        )
        val cursor = (try {
            ctx.contentResolver.query(childrenUri, cols, null, null, null)
        } catch (e: Exception) { null }) ?: return false
        val dirs = ArrayList<String>()
        cursor.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: ""
                val mime = c.getString(2) ?: ""
                val mod = if (c.isNull(3)) 0L else c.getLong(3)
                if (mime == Document.MIME_TYPE_DIR) {
                    if (!name.startsWith(".")) dirs.add(id)
                } else if (name.substringAfterLast('.', "").lowercase() in EXTS) {
                    val uri = DocumentsContract.buildDocumentUriUsingTree(tree, id).toString()
                    val old = existing[uri]
                    out.add(
                        if (old != null && old.lastModified == mod) old.copy(folderId = folderId)
                        else readMeta(ctx, uri, name, folderId, mod)
                    )
                }
            }
        }
        for (d in dirs) walk(ctx, folderId, tree, d, existing, out, depth + 1)
        return true
    }

    private fun readMeta(ctx: Context, uri: String, name: String, folderId: Long, mod: Long): SongEntity {
        var title = ""; var artist = ""; var album = ""; var dur = 0L
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, Uri.parse(uri))
            title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE) ?: ""
            artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                ?: r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST) ?: ""
            album = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM) ?: ""
            dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
        } finally {
            try { r.release() } catch (e: Exception) {}
        }
        if (title.isBlank()) title = name.substringBeforeLast('.')
        return SongEntity(uri, folderId, title.trim(), artist.trim(), album.trim(), dur, name, mod)
    }

    fun displayName(ctx: Context, tree: Uri): String? = try {
        val docId = DocumentsContract.getTreeDocumentId(tree)
        val uri = DocumentsContract.buildDocumentUriUsingTree(tree, docId)
        ctx.contentResolver.query(uri, arrayOf(Document.COLUMN_DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (e: Exception) { null }
}

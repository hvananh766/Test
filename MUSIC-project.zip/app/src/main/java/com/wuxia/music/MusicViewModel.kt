package com.wuxia.music

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionToken
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlin.random.Random

sealed interface Screen {
    data object Home : Screen
    data object Folders : Screen
    data object Playlists : Screen
    data object Albums : Screen
    data object Artists : Screen
    data object Settings : Screen
    data object Equalizer : Screen
    /** kind: ALL, FAV, RECENT, FOLDER, ALBUM, ARTIST, PLAYLIST */
    data class Songs(val kind: String, val key: String, val title: String) : Screen
}

fun SongEntity.toItem(): MediaItem = MediaItem.Builder()
    .setMediaId(uri)
    .setUri(uri)
    .setMediaMetadata(
        MediaMetadata.Builder().setTitle(title)
            .setArtworkUri(Uri.parse(uri))
            .setDurationMs(if (durationMs > 0) durationMs else null)
            .setArtist(artist.ifBlank { album.ifBlank { "MUSIC" } })
            .setAlbumTitle(album.ifBlank { null }).build()
    ).build()

/** 0 artist, 1 song name, 2 filename, 3 newest, 4 oldest, 5 sound quality */
fun sortSongs(l: List<SongEntity>, mode: Int): List<SongEntity> = when (mode) {
    0 -> l.sortedWith(compareBy({ it.artist.lowercase() }, { it.title.lowercase() }))
    1 -> l.sortedBy { it.title.lowercase() }
    2 -> l.sortedBy { it.fileName.lowercase() }
    3 -> l.sortedByDescending { it.lastModified }
    4 -> l.sortedBy { it.lastModified }
    else -> l.sortedWith(
        compareByDescending<SongEntity> { it.isLossless() }
            .thenByDescending { it.bitrate }.thenBy { it.title.lowercase() }
    )
}

class MusicViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val dao = AppDb.get(ctx).dao()
    val prefs = ctx.getSharedPreferences("music_prefs", Context.MODE_PRIVATE)

    // ---- Library (only what lives in user-selected folders) ----
    val folders = dao.folders().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val songs = dao.songs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val favorites = dao.favorites().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val recents = dao.recents().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val playlists = dao.playlists().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val playlistItems = dao.playlistItems().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ---- Navigation / UI ----
    val stack = mutableStateListOf<Screen>(Screen.Home)
    val current: Screen get() = stack.last()
    var showPlayer by mutableStateOf(false)
    var queueOpen by mutableStateOf(false)
    var pickSong by mutableStateOf<SongEntity?>(null)
    var scanning by mutableStateOf(false)

    fun go(s: Screen) { if (stack.last() != s) stack.add(s) }
    fun goRoot(s: Screen) { stack.clear(); stack.add(s) }
    fun back() { if (stack.size > 1) stack.removeAt(stack.lastIndex) }

    // ---- Settings ----
    var dark by mutableStateOf(prefs.getBoolean("dark", true))
    var lang by mutableStateOf(prefs.getString("lang", "vi") ?: "vi")
    var bg by mutableIntStateOf(prefs.getInt("bg", 0))
    var sort by mutableIntStateOf(prefs.getInt("sort2", 3))
    var sleepEnd by mutableLongStateOf(prefs.getLong("sleep_end", 0L))
    var eqPreset by mutableIntStateOf(prefs.getInt("eq_preset", 0))
    var eqBass by mutableFloatStateOf(prefs.getFloat("eq_bass", 0f))
    var eqTreble by mutableFloatStateOf(prefs.getFloat("eq_treble", 0f))

    fun applyDark(b: Boolean) { dark = b; prefs.edit().putBoolean("dark", b).apply() }
    fun applyLang(l: String) { lang = l; prefs.edit().putString("lang", l).apply() }
    fun applyBg(i: Int) { bg = i; prefs.edit().putInt("bg", i).apply() }
    fun applySort(i: Int) { sort = i; prefs.edit().putInt("sort2", i).apply() }

    // ---- Player state ----
    private var controller: MediaController? = null
    var isPlaying by mutableStateOf(false)
    var currentUri by mutableStateOf<String?>(null)
    var currentSong by mutableStateOf<SongEntity?>(null)
    var position by mutableLongStateOf(0L)
    var duration by mutableLongStateOf(0L)
    var shuffle by mutableStateOf(false)
    var repeat by mutableIntStateOf(0)
    var speed by mutableFloatStateOf(1f)
    var queueTick by mutableIntStateOf(0)

    private var lastRecent: String? = null
    private var restored = false
    private var loadedSongs: List<SongEntity>? = null

    init {
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val f = MediaController.Builder(ctx, token).buildAsync()
        f.addListener({
            val c = try { f.get() } catch (e: Exception) { null }
            if (c != null) {
                controller = c
                c.addListener(object : Player.Listener {
                    override fun onEvents(player: Player, events: Player.Events) { sync() }
                })
                c.shuffleModeEnabled = prefs.getBoolean("shuffle", false)
                c.repeatMode = prefs.getInt("repeat", 0)
                c.setPlaybackSpeed(prefs.getFloat("speed", 1f))
                sync()
                tryRestore()
            }
        }, ContextCompat.getMainExecutor(ctx))

        viewModelScope.launch {
            loadedSongs = dao.songs().first()
            tryRestore()
        }
        viewModelScope.launch {
            while (true) {
                delay(500)
                val c = controller
                if (c != null && c.isPlaying) position = c.currentPosition
            }
        }
    }

    private fun tryRestore() {
        if (restored) return
        val c = controller ?: return
        val list = loadedSongs ?: return
        restored = true
        if (c.mediaItemCount > 0) return
        val last = prefs.getString("last_uri", null) ?: return
        val sorted = sortSongs(list, 1)
        val idx = sorted.indexOfFirst { it.uri == last }
        if (idx < 0) return
        c.setMediaItems(sorted.map { it.toItem() }, idx, prefs.getLong("last_pos", 0L))
        c.prepare()
    }

    private fun sync() {
        val c = controller ?: return
        isPlaying = c.isPlaying
        val uri = c.currentMediaItem?.mediaId
        if (uri != currentUri) {
            currentUri = uri
            currentSong = songs.value.firstOrNull { it.uri == uri }
        }
        if (c.isPlaying && uri != null && uri != lastRecent) {
            lastRecent = uri
            viewModelScope.launch { dao.addRecent(RecentEntity(uri, System.currentTimeMillis())) }
        }
        duration = c.duration.coerceAtLeast(0L)
        position = c.currentPosition
        shuffle = c.shuffleModeEnabled
        repeat = c.repeatMode
        speed = c.playbackParameters.speed
        queueTick++
    }

    // ---- Playback actions ----
    fun play(list: List<SongEntity>, index: Int, shuffleOn: Boolean? = null) {
        val c = controller ?: return
        if (list.isEmpty()) return
        c.setMediaItems(list.map { it.toItem() }, index.coerceIn(0, list.lastIndex), 0L)
        if (shuffleOn != null) applyShuffle(shuffleOn)
        c.prepare(); c.play()
    }

    fun shuffleAll(list: List<SongEntity>) { if (list.isNotEmpty()) play(list, Random.nextInt(list.size), true) }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else {
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            if (c.playbackState == Player.STATE_ENDED) c.seekTo(0)
            c.play()
        }
    }
    fun next() { controller?.seekToNextMediaItem() }
    fun prev() { controller?.seekToPrevious() }
    fun seek(ms: Long) { controller?.seekTo(ms); position = ms }
    fun applyShuffle(b: Boolean) { controller?.shuffleModeEnabled = b; prefs.edit().putBoolean("shuffle", b).apply() }
    fun toggleShuffle() = applyShuffle(!shuffle)
    fun cycleRepeat() {
        val m = (repeat + 1) % 3
        controller?.repeatMode = m; prefs.edit().putInt("repeat", m).apply()
    }
    fun applySpeed(s: Float) { controller?.setPlaybackSpeed(s); prefs.edit().putFloat("speed", s).apply() }
    fun playNext(s: SongEntity) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) play(listOf(s), 0) else c.addMediaItem(c.currentMediaItemIndex + 1, s.toItem())
    }
    fun queue(): List<MediaItem> {
        val c = controller ?: return emptyList()
        return List(c.mediaItemCount) { c.getMediaItemAt(it) }
    }
    fun jumpTo(i: Int) { controller?.seekToDefaultPosition(i); controller?.play() }

    // ---- Favorites / playlists ----
    fun toggleFav(uri: String) = viewModelScope.launch {
        if (favorites.value.contains(uri)) dao.removeFavorite(uri) else dao.addFavorite(FavoriteEntity(uri))
    }
    fun createPlaylist(name: String, folderId: Long?, addUri: String? = null) = viewModelScope.launch {
        val id = dao.insertPlaylist(PlaylistEntity(name = name, folderId = folderId))
        if (addUri != null) dao.addToPlaylist(PlaylistItem(id, addUri))
    }
    fun renamePlaylist(id: Long, name: String) = viewModelScope.launch { dao.renamePlaylist(id, name) }
    fun deletePlaylist(id: Long) = viewModelScope.launch { dao.deletePlaylist(id) }
    fun addToPlaylist(pid: Long, uri: String) = viewModelScope.launch { dao.addToPlaylist(PlaylistItem(pid, uri)) }
    fun removeFromPlaylist(pid: Long, uri: String) = viewModelScope.launch { dao.removeFromPlaylist(pid, uri) }

    // ---- Folder management (SAF) ----
    fun addFolder(uri: Uri) = viewModelScope.launch {
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {}
        val label = withContext(Dispatchers.IO) { Scanner.displayName(ctx, uri) } ?: "Music"
        val id = dao.insertFolder(FolderEntity(treeUri = uri.toString(), label = label))
        if (id > 0) scan(FolderEntity(id, uri.toString(), label))
    }

    fun refreshFolder(id: Long) = viewModelScope.launch {
        dao.folderList().firstOrNull { it.id == id }?.let { scan(it) }
    }

    fun refreshAll() = viewModelScope.launch { dao.folderList().forEach { scan(it) } }

    private suspend fun scan(f: FolderEntity) {
        scanning = true
        try {
            val existing = dao.songsOf(f.id).associateBy { it.uri }
            val result = withContext(Dispatchers.IO) { Scanner.scan(ctx, f.id, Uri.parse(f.treeUri), existing) }
            if (result == null) {
                dao.deleteSongsOf(f.id); dao.setMissing(f.id, true)
            } else {
                dao.replaceSongs(f.id, result); dao.setMissing(f.id, false)
            }
        } finally { scanning = false }
    }

    fun renameFolder(id: Long, label: String) = viewModelScope.launch { dao.renameFolder(id, label) }

    /** Removes the folder from the app only. Original files are never touched. */
    fun removeFolder(f: FolderEntity) = viewModelScope.launch {
        try {
            ctx.contentResolver.releasePersistableUriPermission(
                Uri.parse(f.treeUri), Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (e: Exception) {}
        if (currentSong?.folderId == f.id) { controller?.stop(); controller?.clearMediaItems() }
        dao.removeFolder(f.id)
    }

    // ---- Equalizer / sleep timer (handled inside the service) ----
    fun setEq(preset: Int = eqPreset, bass: Float = eqBass, treble: Float = eqTreble) {
        eqPreset = preset; eqBass = bass; eqTreble = treble
        prefs.edit().putInt("eq_preset", preset).putFloat("eq_bass", bass).putFloat("eq_treble", treble).apply()
        controller?.sendCustomCommand(
            SessionCommand(PlaybackService.CMD_EQ, Bundle.EMPTY),
            Bundle().apply { putInt("preset", preset); putFloat("bass", bass); putFloat("treble", treble) }
        )
    }

    fun setSleep(min: Int) {
        sleepEnd = if (min > 0) System.currentTimeMillis() + min * 60_000L else 0L
        prefs.edit().putLong("sleep_end", sleepEnd).apply()
        controller?.sendCustomCommand(
            SessionCommand(PlaybackService.CMD_SLEEP, Bundle.EMPTY),
            Bundle().apply { putInt("min", min) }
        )
    }

    override fun onCleared() {
        controller?.release()
        super.onCleared()
    }
}

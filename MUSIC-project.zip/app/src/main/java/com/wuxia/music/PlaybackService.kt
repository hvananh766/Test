package com.wuxia.music

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.util.BitmapLoader
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.*
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

/** Loads embedded cover art lazily for the current song (used by notification / lock screen). */
class ArtBitmapLoader(private val ctx: Context) : BitmapLoader {
    private val exec = MoreExecutors.listeningDecorator(Executors.newSingleThreadExecutor())
    private fun fallback(): Bitmap = BitmapFactory.decodeResource(ctx.resources, R.drawable.ic_art_fallback)
    override fun supportsMimeType(mimeType: String): Boolean = true
    override fun decodeBitmap(data: ByteArray): com.google.common.util.concurrent.ListenableFuture<Bitmap> =
        exec.submit(Callable<Bitmap> { BitmapFactory.decodeByteArray(data, 0, data.size) ?: fallback() })
    override fun loadBitmap(uri: Uri): com.google.common.util.concurrent.ListenableFuture<Bitmap> =
        exec.submit(Callable<Bitmap> { ArtCache.load(ctx, uri.toString(), 512) ?: fallback() })
}

class PlaybackService : MediaSessionService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var favs: Set<String> = emptySet()
    private var session: MediaSession? = null
    private var eq: Equalizer? = null
    private var boost: BassBoost? = null
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("music_prefs", MODE_PRIVATE) }

    private val saver = object : Runnable {
        override fun run() { savePos(); handler.postDelayed(this, 5000) }
    }
    private val sleeper = Runnable {
        session?.player?.pause()
        prefs.edit().putLong("sleep_end", 0L).apply()
    }

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA).build(), true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                handler.removeCallbacks(saver)
                savePos()
                if (isPlaying) handler.postDelayed(saver, 5000)
            }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { updateLayout() }
            override fun onAudioSessionIdChanged(audioSessionId: Int) { setupEffects(audioSessionId) }
            override fun onPlayerError(error: PlaybackException) {
                // Skip unplayable / missing files instead of stopping.
                val p = session?.player ?: return
                if (p.hasNextMediaItem()) { p.seekToNextMediaItem(); p.prepare(); p.play() }
            }
        })
        setMediaNotificationProvider(
            DefaultMediaNotificationProvider(this).also { it.setSmallIcon(R.drawable.ic_stat_music) }
        )
        session = MediaSession.Builder(this, player)
            .setBitmapLoader(ArtBitmapLoader(this))
            .setCallback(object : MediaSession.Callback {
            override fun onConnect(
                session: MediaSession, controller: MediaSession.ControllerInfo
            ): MediaSession.ConnectionResult {
                val cmds = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon()
                    .add(SessionCommand(CMD_EQ, Bundle.EMPTY))
                    .add(SessionCommand(CMD_SLEEP, Bundle.EMPTY))
                    .add(SessionCommand(CMD_FAV, Bundle.EMPTY)).build()
                return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                    .setAvailableSessionCommands(cmds).build()
            }

            override fun onCustomCommand(
                session: MediaSession, controller: MediaSession.ControllerInfo,
                customCommand: SessionCommand, args: Bundle
            ): ListenableFuture<SessionResult> {
                when (customCommand.customAction) {
                    CMD_EQ -> {
                        prefs.edit().putInt("eq_preset", args.getInt("preset"))
                            .putFloat("eq_bass", args.getFloat("bass"))
                            .putFloat("eq_treble", args.getFloat("treble")).apply()
                        applyEq()
                    }
                    CMD_FAV -> {
                        val id = session.player.currentMediaItem?.mediaId
                        if (id != null) scope.launch(Dispatchers.IO) {
                            val dao = AppDb.get(this@PlaybackService).dao()
                            if (id in favs) dao.removeFavorite(id) else dao.addFavorite(FavoriteEntity(id))
                        }
                    }
                    CMD_SLEEP -> {
                        handler.removeCallbacks(sleeper)
                        val min = args.getInt("min")
                        if (min > 0) handler.postDelayed(sleeper, min * 60_000L)
                    }
                }
                return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
            }
        }).build()
        setupEffects(player.audioSessionId)
        scope.launch {
            AppDb.get(this@PlaybackService).dao().favorites().collect {
                favs = it.toSet(); updateLayout()
            }
        }
        updateLayout()
    }

    /** Heart button shown next to prev / play / next in the notification and lock screen. */
    private fun updateLayout() {
        val s = session ?: return
        val id = s.player.currentMediaItem?.mediaId
        val fav = id != null && id in favs
        val btn = CommandButton.Builder()
            .setDisplayName(if (fav) "Unfavorite" else "Favorite")
            .setIconResId(if (fav) R.drawable.ic_heart_filled else R.drawable.ic_heart)
            .setSessionCommand(SessionCommand(CMD_FAV, Bundle.EMPTY))
            .build()
        s.setCustomLayout(ImmutableList.of(btn))
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        scope.cancel()
        savePos()
        releaseEffects()
        session?.run { player.release(); release() }
        session = null
        super.onDestroy()
    }

    private fun savePos() {
        val p = session?.player ?: return
        val id = p.currentMediaItem?.mediaId ?: return
        prefs.edit().putString("last_uri", id).putLong("last_pos", p.currentPosition).apply()
    }

    private fun releaseEffects() {
        try { eq?.release() } catch (e: Exception) {}
        try { boost?.release() } catch (e: Exception) {}
        eq = null; boost = null
    }

    // Only enable effects the device actually supports.
    private fun setupEffects(sid: Int) {
        releaseEffects()
        var ok = false
        try { eq = Equalizer(0, sid).also { it.enabled = true }; ok = true } catch (e: Exception) { eq = null }
        try { boost = BassBoost(0, sid).also { it.enabled = true } } catch (e: Exception) { boost = null }
        prefs.edit().putBoolean("eq_supported", ok).apply()
        applyEq()
    }

    private fun applyEq() {
        val e = eq ?: return
        val preset = prefs.getInt("eq_preset", 0).coerceIn(0, PRESETS.lastIndex)
        val bass = prefs.getFloat("eq_bass", 0f)
        val treble = prefs.getFloat("eq_treble", 0f)
        try {
            val n = e.numberOfBands.toInt()
            val lo = e.bandLevelRange[0].toInt()
            val hi = e.bandLevelRange[1].toInt()
            val curve = PRESETS[preset]
            for (i in 0 until n) {
                val f = if (n == 1) 0f else i.toFloat() / (n - 1)
                val pos = f * (curve.size - 1)
                val a = pos.toInt().coerceAtMost(curve.size - 2)
                val frac = pos - a
                var lvl = (curve[a] + (curve[a + 1] - curve[a]) * frac) * 100f
                if (i == 0) lvl += bass * hi
                if (i == n - 1) lvl += treble * hi
                e.setBandLevel(i.toShort(), lvl.toInt().coerceIn(lo, hi).toShort())
            }
            boost?.let {
                if (it.strengthSupported) it.setStrength((bass.coerceAtLeast(0f) * 1000).toInt().coerceIn(0, 1000).toShort())
            }
        } catch (ex: Exception) {}
    }

    companion object {
        const val CMD_EQ = "com.wuxia.music.EQ"
        const val CMD_SLEEP = "com.wuxia.music.SLEEP"
        const val CMD_FAV = "com.wuxia.music.FAV"
        // Normal, Rock, Pop, Classical, Jazz (dB at 5 points from low to high)
        val PRESETS = listOf(
            floatArrayOf(0f, 0f, 0f, 0f, 0f),
            floatArrayOf(5f, 3f, -1f, 3f, 5f),
            floatArrayOf(-1f, 2f, 5f, 2f, -1f),
            floatArrayOf(4f, 3f, -2f, 3f, 4f),
            floatArrayOf(4f, 2f, -2f, 2f, 5f)
        )
    }
}

package com.wuxia.music

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.sin

val Gold = Color(0xFFC9A961)
val Jade = Color(0xFF3FB68B)

val LocalLang = compositionLocalOf { "vi" }
val LocalPickFolder = staticCompositionLocalOf<() -> Unit> { {} }

@Composable
fun tr(vi: String, en: String): String = if (LocalLang.current == "vi") vi else en

@Composable
fun WuxiaTheme(dark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (dark) darkColorScheme(
        primary = Jade, onPrimary = Color(0xFF04261B), secondary = Gold,
        background = Color(0xFF0A1220), surface = Color(0xFF111B2E),
        onBackground = Color(0xFFEAE6D8), onSurface = Color(0xFFEAE6D8),
        surfaceVariant = Color(0xFF1A2740), onSurfaceVariant = Color(0xFFB9B5A6),
        outline = Color(0x55C9A961)
    ) else lightColorScheme(
        primary = Color(0xFF1F7A5C), onPrimary = Color.White, secondary = Color(0xFF8A6D1F),
        background = Color(0xFFF1EAD6), surface = Color(0xFFE9E0C6),
        onBackground = Color(0xFF1B2230), onSurface = Color(0xFF1B2230),
        surfaceVariant = Color(0xFFDDD3B6), onSurfaceVariant = Color(0xFF4A4A3E),
        outline = Color(0x558A6D1F)
    )
    val serif = FontFamily.Serif
    MaterialTheme(
        colorScheme = scheme,
        typography = Typography(
            headlineMedium = TextStyle(fontFamily = serif, fontWeight = FontWeight.Bold, fontSize = 26.sp),
            titleLarge = TextStyle(fontFamily = serif, fontWeight = FontWeight.SemiBold, fontSize = 20.sp),
            titleMedium = TextStyle(fontFamily = serif, fontWeight = FontWeight.Medium, fontSize = 16.sp)
        ),
        content = content
    )
}

// ---------- Ink-painting background: moon, mountains, mist, petals ----------
private fun palette(dark: Boolean, v: Int): List<Color> = if (dark) when (v) {
    1 -> listOf(Color(0xFF04120F), Color(0xFF0F3A30), Color(0xFF06201B), Color(0xFFDDEBD0))
    2 -> listOf(Color(0xFF1A1020), Color(0xFF4A2E3F), Color(0xFF1E1226), Color(0xFFF3D9A4))
    else -> listOf(Color(0xFF050A14), Color(0xFF10213A), Color(0xFF0B1A2C), Color(0xFFEFE6C8))
} else when (v) {
    1 -> listOf(Color(0xFFE6EEDC), Color(0xFFB9CDB0), Color(0xFF2F5A48), Color(0xFFC9A961))
    2 -> listOf(Color(0xFFF7E3D4), Color(0xFFE2B9A0), Color(0xFF5A3A4A), Color(0xFFC0504A))
    else -> listOf(Color(0xFFF6F0DC), Color(0xFFD9CFB0), Color(0xFF3A4A52), Color(0xFFB5483A))
}

@Composable
fun InkBackground(dark: Boolean, variant: Int) {
    val p = remember(dark, variant) { palette(dark, variant) }
    val t = rememberInfiniteTransition(label = "bg").animateFloat(
        0f, 1f, infiniteRepeatable(tween(90000, easing = LinearEasing)), label = "t"
    )
    val mist = if (dark) Color.White.copy(alpha = 0.05f) else Color.White.copy(alpha = 0.35f)
    val petal = if (dark) Color(0xFFF3C6D0).copy(alpha = 0.55f) else Color(0xFFD97A8E).copy(alpha = 0.6f)
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height; val tv = t.value
        drawRect(Brush.verticalGradient(listOf(p[0], p[1])))
        val mc = Offset(w * .74f, h * .15f)
        drawCircle(p[3].copy(alpha = .10f), w * .24f, mc)
        drawCircle(p[3].copy(alpha = .18f), w * .15f, mc)
        drawCircle(p[3].copy(alpha = if (dark) .9f else .8f), w * .08f, mc)
        for (layer in 0..2) {
            val base = h * (0.52f + 0.1f * layer)
            val amp = h * (0.17f - 0.03f * layer)
            val path = Path().apply {
                moveTo(0f, h); lineTo(0f, base)
                val steps = 40
                for (i in 0..steps) {
                    val x = w * i / steps
                    val u = x / w
                    val y = base - amp *
                        (0.5f + 0.5f * sin(u * (4f + layer * 2f) * PI.toFloat() + layer * 2.1f)) *
                        (0.55f + 0.45f * sin(u * 11f + layer * 1.3f))
                    lineTo(x, y)
                }
                lineTo(w, h); close()
            }
            drawPath(path, p[2].copy(alpha = 0.35f + 0.25f * layer))
        }
        for (i in 0 until 3) {
            val x = (((tv * (1 + i) + i * .33f) % 1f) * 1.6f - 0.8f) * w
            drawOval(mist, Offset(x, h * (0.50f + 0.11f * i)), Size(w * .9f, h * .06f))
        }
        for (i in 0 until 12) {
            val sp = 3 * (1 + i % 3)
            val y = ((tv * sp + i / 12f) % 1f) * (h + 40f) - 20f
            val x = ((i * 0.083f + 0.04f) % 1f) * w + sin((tv * sp + i) * 2f * PI.toFloat()) * 24f
            rotate(tv * 360f * sp + i * 30f, Offset(x, y)) {
                drawOval(petal, Offset(x - 5f, y - 3f), Size(10f, 6f))
            }
        }
    }
}

// ---------- Artwork ----------
object ArtCache {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val none = java.util.Collections.synchronizedSet(HashSet<String>())

    fun get(uri: String): Bitmap? = cache.get(uri)

    fun load(ctx: android.content.Context, uri: String, target: Int): Bitmap? {
        cache.get(uri)?.let { return it }
        if (uri in none) return null
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, Uri.parse(uri))
            val bytes = r.embeddedPicture
            if (bytes == null) { none.add(uri); return null }
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
            var s = 1
            while (o.outWidth / (s * 2) >= target && o.outHeight / (s * 2) >= target) s *= 2
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
            if (bmp != null) cache.put(uri, bmp) else none.add(uri)
            return bmp
        } catch (e: Exception) {
            none.add(uri); return null
        } finally {
            try { r.release() } catch (e: Exception) {}
        }
    }
}

@Composable
fun Artwork(uri: String?, modifier: Modifier = Modifier, round: Dp = 12.dp) {
    val ctx = LocalContext.current
    var bmp by remember(uri) { mutableStateOf(uri?.let { ArtCache.get(it) }) }
    LaunchedEffect(uri) {
        if (uri != null && bmp == null) bmp = withContext(Dispatchers.IO) { ArtCache.load(ctx, uri, 512) }
    }
    Box(
        modifier.clip(RoundedCornerShape(round))
            .background(Brush.linearGradient(listOf(Color(0xFF14463A), Color(0xFF0B1A2C)))),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text("樂", color = Gold.copy(alpha = .85f), fontFamily = FontFamily.Serif, fontSize = 22.sp)
    }
}

// ---------- Small shared components ----------
fun fmt(ms: Long): String {
    val t = (ms.coerceAtLeast(0L)) / 1000
    return "%d:%02d".format(t / 60, t % 60)
}

@Composable fun artistOf(s: SongEntity) = s.artist.ifBlank { tr("Không rõ nghệ sĩ", "Unknown artist") }
@Composable fun albumOf(s: SongEntity) = s.album.ifBlank { tr("Không rõ album", "Unknown album") }

@Composable
fun panelColor() = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f)

@Composable
fun SectionTitle(text: String) {
    Text(
        text, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.secondary,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

@Composable
fun TopBar(title: String, onBack: (() -> Unit)?, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) IconButton(onClick = onBack) {
            Icon(Icons.Filled.ArrowBack, null, tint = MaterialTheme.colorScheme.secondary)
        } else Spacer(Modifier.width(12.dp))
        Text(
            title, style = MaterialTheme.typography.headlineMedium, maxLines = 1,
            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
        )
        actions()
    }
}

@Composable
fun SongRow(
    vm: MusicViewModel, s: SongEntity, playing: Boolean, isFav: Boolean,
    onClick: () -> Unit, onRemove: (() -> Unit)? = null
) {
    var menu by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Artwork(s.uri, Modifier.size(48.dp), 8.dp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium,
                color = if (playing) cs.primary else cs.onBackground
            )
            Text(
                "${artistOf(s)} · ${albumOf(s)}", style = MaterialTheme.typography.bodySmall,
                maxLines = 1, overflow = TextOverflow.Ellipsis, color = cs.onSurfaceVariant
            )
        }
        Text(fmt(s.durationMs), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        IconButton(onClick = { vm.toggleFav(s.uri) }) {
            Icon(
                if (isFav) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, null,
                tint = if (isFav) Gold else cs.onSurfaceVariant
            )
        }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, null, tint = cs.onSurfaceVariant) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text(tr("Phát tiếp theo", "Play next")) },
                    onClick = { menu = false; vm.playNext(s) })
                DropdownMenuItem(text = { Text(tr("Thêm vào playlist", "Add to playlist")) },
                    onClick = { menu = false; vm.pickSong = s })
                if (onRemove != null) DropdownMenuItem(text = { Text(tr("Xoá khỏi playlist", "Remove from playlist")) },
                    onClick = { menu = false; onRemove() })
            }
        }
    }
}

@Composable
fun TextDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(text, { text = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (text.isNotBlank()) onOk(text.trim()) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Huỷ", "Cancel")) } }
    )
}

@Composable
fun NewPlaylistDialog(folders: List<FolderEntity>, onDismiss: () -> Unit, onCreate: (String, Long?) -> Unit) {
    var name by remember { mutableStateOf("") }
    var folder by remember { mutableStateOf<Long?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Playlist mới", "New playlist")) },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text(tr("Tên", "Name")) })
                if (folders.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(tr("Gắn với thư mục (tuỳ chọn)", "Bind to folder (optional)"), style = MaterialTheme.typography.bodySmall)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        item { FilterChip(folder == null, { folder = null }, { Text(tr("Chung", "Any")) }) }
                        items(folders, key = { it.id }) { f ->
                            FilterChip(folder == f.id, { folder = f.id }, { Text(f.label, maxLines = 1) })
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onCreate(name.trim(), folder) }) { Text(tr("Tạo", "Create")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Huỷ", "Cancel")) } }
    )
}

@Composable
fun AddToPlaylistDialog(vm: MusicViewModel, song: SongEntity) {
    val pls by vm.playlists.collectAsState()
    val folders by vm.folders.collectAsState()
    var creating by remember { mutableStateOf(false) }
    val usable = pls.filter { it.folderId == null || it.folderId == song.folderId }
    if (creating) {
        NewPlaylistDialog(folders, { creating = false }) { n, f ->
            vm.createPlaylist(n, f, song.uri); creating = false; vm.pickSong = null
        }
        return
    }
    AlertDialog(
        onDismissRequest = { vm.pickSong = null },
        title = { Text(tr("Thêm vào playlist", "Add to playlist")) },
        text = {
            LazyColumn {
                items(usable, key = { it.id }) { p ->
                    Text(p.name, Modifier.fillMaxWidth().clickable {
                        vm.addToPlaylist(p.id, song.uri); vm.pickSong = null
                    }.padding(vertical = 12.dp))
                }
            }
        },
        confirmButton = { TextButton(onClick = { creating = true }) { Text(tr("Playlist mới", "New playlist")) } },
        dismissButton = { TextButton(onClick = { vm.pickSong = null }) { Text(tr("Đóng", "Close")) } }
    )
}

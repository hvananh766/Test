package com.wuxia.music

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.sin

val Accent = Color(0xFFF26B63)

val LocalLang = compositionLocalOf { "vi" }
val LocalPickFolder = staticCompositionLocalOf<() -> Unit> { {} }

@Composable
fun tr(vi: String, en: String): String = if (LocalLang.current == "vi") vi else en

@Composable
fun WuxiaTheme(dark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (dark) darkColorScheme(
        primary = Accent, onPrimary = Color.White, secondary = Color(0xFFCFCFCF),
        background = Color(0xFF1C1C1C), surface = Color(0xFF2A2A2A),
        onBackground = Color.White, onSurface = Color.White,
        surfaceVariant = Color(0xFF333333), onSurfaceVariant = Color(0xFF9A9A9A),
        secondaryContainer = Color(0xFF3A3A3A), onSecondaryContainer = Color.White,
        outline = Color(0xFF444444)
    ) else lightColorScheme(
        primary = Accent, onPrimary = Color.White, secondary = Color(0xFF444444),
        background = Color(0xFFF6F6F6), surface = Color.White,
        onBackground = Color(0xFF1C1C1C), onSurface = Color(0xFF1C1C1C),
        surfaceVariant = Color(0xFFE8E8E8), onSurfaceVariant = Color(0xFF6B6B6B),
        secondaryContainer = Color(0xFFE0E0E0), onSecondaryContainer = Color(0xFF1C1C1C),
        outline = Color(0xFFDDDDDD)
    )
    MaterialTheme(
        colorScheme = scheme,
        typography = Typography(
            headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 26.sp),
            titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 20.sp),
            titleMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 16.sp)
        ),
        content = content
    )
}

// ---------- Artwork ----------
object ArtCache {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val none = java.util.Collections.synchronizedSet(HashSet<String>())

    fun get(uri: String): Bitmap? = cache.get(uri)

    fun load(ctx: android.content.Context, uri: String, target: Int): Bitmap? {
        cache.get(uri)?.let { return it }
        if (uri in none) return null
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, Uri.parse(uri))
            val bytes = r.embeddedPicture
            if (bytes == null) { none.add(uri); return null }
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
            var s = 1
            while (o.outWidth / (s * 2) >= target && o.outHeight / (s * 2) >= target) s *= 2
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
            if (bmp != null) cache.put(uri, bmp) else none.add(uri)
            return bmp
        } catch (e: Exception) {
            none.add(uri); return null
        } finally {
            try { r.release() } catch (e: Exception) {}
        }
    }
}

@Composable
fun Artwork(uri: String?, modifier: Modifier = Modifier, round: Dp = 12.dp) {
    val ctx = LocalContext.current
    var bmp by remember(uri) { mutableStateOf(uri?.let { ArtCache.get(it) }) }
    LaunchedEffect(uri) {
        if (uri != null && bmp == null) bmp = withContext(Dispatchers.IO) { ArtCache.load(ctx, uri, 512) }
    }
    Box(
        modifier.clip(RoundedCornerShape(round)).background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(
            Icons.Filled.MusicNote, null, Modifier.fillMaxSize(0.5f),
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
        )
    }
}

// ---------- Small shared components ----------
fun fmt(ms: Long): String {
    val t = (ms.coerceAtLeast(0L)) / 1000
    return "%d:%02d".format(t / 60, t % 60)
}

@Composable fun artistOf(s: SongEntity) = s.artist.ifBlank { tr("Không rõ nghệ sĩ", "Unknown artist") }
@Composable fun albumOf(s: SongEntity) = s.album.ifBlank { tr("Không rõ album", "Unknown album") }

@Composable
fun panelColor() = MaterialTheme.colorScheme.surface

@Composable
fun SectionTitle(text: String) {
    Text(
        text, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

@Composable
fun TopBar(title: String, onBack: (() -> Unit)?, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) IconButton(onClick = onBack) {
            Icon(Icons.Filled.ArrowBack, null, tint = MaterialTheme.colorScheme.secondary)
        } else Spacer(Modifier.width(12.dp))
        Text(
            title, style = MaterialTheme.typography.headlineMedium, maxLines = 1,
            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
        )
        actions()
    }
}

@Composable
fun SongRow(
    vm: MusicViewModel, s: SongEntity, playing: Boolean, isFav: Boolean,
    onClick: () -> Unit, onRemove: (() -> Unit)? = null
) {
    var menu by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Artwork(s.uri, Modifier.size(48.dp), 8.dp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium,
                color = if (playing) cs.primary else cs.onBackground
            )
            Text(
                "${artistOf(s)} · ${albumOf(s)}", style = MaterialTheme.typography.bodySmall,
                maxLines = 1, overflow = TextOverflow.Ellipsis, color = cs.onSurfaceVariant
            )
        }
        Text(fmt(s.durationMs), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        IconButton(onClick = { vm.toggleFav(s.uri) }) {
            Icon(
                if (isFav) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, null,
                tint = if (isFav) Accent else cs.onSurfaceVariant
            )
        }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, null, tint = cs.onSurfaceVariant) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text(tr("Phát tiếp theo", "Play next")) },
                    onClick = { menu = false; vm.playNext(s) })
                DropdownMenuItem(text = { Text(tr("Thêm vào playlist", "Add to playlist")) },
                    onClick = { menu = false; vm.pickSong = s })
                if (onRemove != null) DropdownMenuItem(text = { Text(tr("Xoá khỏi playlist", "Remove from playlist")) },
                    onClick = { menu = false; onRemove() })
            }
        }
    }
}

@Composable
fun TextDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(text, { text = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (text.isNotBlank()) onOk(text.trim()) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Huỷ", "Cancel")) } }
    )
}

@Composable
fun NewPlaylistDialog(folders: List<FolderEntity>, onDismiss: () -> Unit, onCreate: (String, Long?) -> Unit) {
    var name by remember { mutableStateOf("") }
    var folder by remember { mutableStateOf<Long?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Playlist mới", "New playlist")) },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text(tr("Tên", "Name")) })
                if (folders.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(tr("Gắn với thư mục (tuỳ chọn)", "Bind to folder (optional)"), style = MaterialTheme.typography.bodySmall)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        item { FilterChip(folder == null, { folder = null }, { Text(tr("Chung", "Any")) }) }
                        items(folders, key = { it.id }) { f ->
                            FilterChip(folder == f.id, { folder = f.id }, { Text(f.label, maxLines = 1) })
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onCreate(name.trim(), folder) }) { Text(tr("Tạo", "Create")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Huỷ", "Cancel")) } }
    )
}

@Composable
fun AddToPlaylistDialog(vm: MusicViewModel, song: SongEntity) {
    val pls by vm.playlists.collectAsState()
    val folders by vm.folders.collectAsState()
    var creating by remember { mutableStateOf(false) }
    val usable = pls.filter { it.folderId == null || it.folderId == song.folderId }
    if (creating) {
        NewPlaylistDialog(folders, { creating = false }) { n, f ->
            vm.createPlaylist(n, f, song.uri); creating = false; vm.pickSong = null
        }
        return
    }
    AlertDialog(
        onDismissRequest = { vm.pickSong = null },
        title = { Text(tr("Thêm vào playlist", "Add to playlist")) },
        text = {
            LazyColumn {
                items(usable, key = { it.id }) { p ->
                    Text(p.name, Modifier.fillMaxWidth().clickable {
                        vm.addToPlaylist(p.id, song.uri); vm.pickSong = null
                    }.padding(vertical = 12.dp))
                }
            }
        },
        confirmButton = { TextButton(onClick = { creating = true }) { Text(tr("Playlist mới", "New playlist")) } },
        dismissButton = { TextButton(onClick = { vm.pickSong = null }) { Text(tr("Đóng", "Close")) } }
    )
}
